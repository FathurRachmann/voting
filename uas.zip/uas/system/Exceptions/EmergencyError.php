<?php namespace CodeIgniter\Exceptions;

/**
 * Error: system is unusable
 */

class EmergencyError extends \Error
{

}
