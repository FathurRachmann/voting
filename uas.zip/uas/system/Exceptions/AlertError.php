<?php namespace CodeIgniter\Exceptions;

/**
 * Error: Action must be taken immediately (system/db down, etc)
 */

class AlertError extends \Error
{

}
