<?php
namespace App\Controllers;

class Users extends BaseControllers 
{
    public function index() 
    {
      //return view('welcome message');
      echo "Ini Halaman index pada controller users";
    }
}
?>
